# RavenHawkTech → Tumblr Publisher Publisher v2.0.0

Basic Tumblr publishing tools for WordPress posts, queue processing, OAuth connection, and post logging. Visit https://ravenhawktech.com for RavenHawkTech.

```text
```

## What changed in v0.5.6

- Removed Facebook, Instagram, and LinkedIn provider UI from the plugin.
- Focused the plugin only on Tumblr.
- Added a built-in **Connect Tumblr** OAuth flow.
- Stores the final Tumblr OAuth Token and OAuth Token Secret automatically.
- Adds a **Process Queue Now** button.
- Keeps queue/log tracking.
- Sends WordPress posts to Tumblr as photo posts when a featured image exists.
- Sends WordPress posts to Tumblr as link posts when no featured image exists.

## Setup

1. Create a Tumblr application.
2. Add this callback URL in Tumblr:

```text
https://YOUR-SITE/wp-admin/admin-post.php?action=rsp_tumblr_oauth_callback
```

3. In WordPress, go to **RavenHawkTech → Tumblr Publisher**.
4. Add:
   - Tumblr Blog Identifier
   - Tumblr OAuth Key
   - Tumblr OAuth Secret
5. Save settings.
6. Click **Connect Tumblr**.
7. Authorize the app in Tumblr.
8. Return to WordPress and confirm the plugin says **Connected**.

## Usage

1. Edit a WordPress post.
2. Check **Send this post to Tumblr**.
3. Check **Tumblr Bridge**.
4. Publish the post or click **Queue Now**.
5. Go to **RavenHawkTech → Tumblr Queue / Logs**.
6. Click **Process Queue Now** if needed.

## Recommended Tumblr State

Use:

```text
queue
```

while testing. Switch to `published` after the Tumblr → Instagram → Facebook automation is verified.


## v0.5.6 OAuth Fix

- Sends `oauth_callback` in the OAuth Authorization header during request-token flow.
- Sends `oauth_verifier` in the OAuth Authorization header during access-token flow.
- Uses a normalized callback URL based on the site URL.
- Stores the temporary request token secret by token as well as by user session.
- Improves callback error guidance if Tumblr returns to WordPress without the expected verifier.

Use this callback URL in Tumblr:

```text
https://ravenhawktech.com/wp-admin/admin-post.php?action=rsp_tumblr_oauth_callback
```


## v0.5.6 Callback Fix

This version changes the primary Tumblr callback to the plugin settings page instead of `admin-post.php`.

Use this primary callback URL in Tumblr:

```text
https://ravenhawktech.com/wp-admin/admin.php?page=rsp-settings&rsp_tumblr_oauth_callback=1
```

Fallback callback still supported:

```text
https://ravenhawktech.com/wp-admin/admin-post.php?action=rsp_tumblr_oauth_callback
```

If the Tumblr authorize redirect still behaves strangely, the settings page now shows the last generated Tumblr authorize URL so it can be opened manually.


## v0.5.6 Queue Processing Fix

- `Process Queue Now` now forces queued items to run immediately.
- Failed items are reset and retried when using the manual button.
- The queue page now shows a result notice with Found / Published / Failed / Skipped counts.
- Added Remote ID display for successful Tumblr posts.
- Expanded queue response visibility for easier troubleshooting.


## v0.5.6 Queue Cleanup

Added queue cleanup controls on **RavenHawkTech → Tumblr Queue / Logs**:

- Clear Queued
- Clear Failed
- Clear Published
- Clear All

These actions only remove local WordPress queue/log rows. They do not delete posts already created on Tumblr.


## v0.5.6 Tumblr Image Format Fix

Tumblr photo posts only support common image formats such as JPG, PNG, and GIF. WordPress featured images may be WebP or AVIF depending on the site, theme, or optimization plugins.

This version:
- Checks the featured image file extension before sending a Tumblr photo post.
- Uses JPG, JPEG, PNG, or GIF featured images as Tumblr photo posts.
- Tries alternate WordPress image sizes if the full-size image is unsupported.
- Falls back to a Tumblr link post when the image format is unsupported.
- Prevents the Tumblr error: `Nice image, but we don't support that format`.


## v0.5.6 Reliable Tumblr Link Mode

Tumblr can reject WordPress featured images when an image optimization plugin, CDN, or theme serves WebP/AVIF behind a URL that looks like JPG/PNG.

This version forces Tumblr posts to use reliable **link posts** instead of photo posts.

Benefits:
- Avoids Tumblr's unsupported image format error.
- Keeps the WordPress article title, excerpt, tags, and link.
- Keeps the Tumblr bridge workflow stable.
- Best fit for WordPress → Tumblr → Instagram/Facebook automation testing.

If you want photo-post mode again later, use JPG/PNG featured images directly or disable WebP/AVIF conversion in your image optimization/CDN layer.


## v0.5.6 Image Conversion for Tumblr

This version attempts to preserve Tumblr photo posts by converting unsupported WordPress featured images to JPEG before publishing.

Behavior:
- If the featured image is already JPG, JPEG, PNG, or GIF, it is used directly.
- If the featured image is WebP, AVIF, or another unsupported format, the plugin attempts to convert it to JPEG using WordPress image editor support.
- Converted images are saved under:

```text
/wp-content/uploads/ravenhawk-tumblr/
```

- The converted JPEG URL is cached in attachment metadata.
- If conversion fails, the plugin falls back to a reliable Tumblr link post.

Requirements:
- The WordPress server must have GD or ImageMagick available.
- The original featured image must be readable by WordPress.
- The uploads folder must be writable.


## v0.5.6 Hotfix

- Fixed a stale method call: `tumblr_supported_image_url()`.
- The provider now uses `tumblr_safe_featured_image_url()` consistently.
- Keeps the v0.4.7 image conversion/fallback behavior.


## v0.5.6 Local Binary Image Upload

This version avoids Tumblr fetching the WordPress image URL.

Why:
- A featured image can be a PNG in WordPress.
- A CDN or image optimization layer can still serve WebP/AVIF to Tumblr.
- Tumblr then rejects the remote image even though the WordPress file looks valid.

Fix:
- Reads the local WordPress featured image file from disk.
- If the local file is JPG, JPEG, PNG, or GIF, it uploads the binary image data directly to Tumblr.
- If the local file is unsupported, it attempts to convert it to JPEG first.
- If image handling fails, it falls back to a Tumblr link post.


## v0.5.6 Tumblr Photo Upload Fallback

- Sends local image uploads using `data64` instead of raw binary form data.
- If Tumblr still rejects the photo payload, the plugin automatically retries as a link post.
- This prevents queue items from remaining failed due to Tumblr image validation.
- The queue response records the original Tumblr image error when fallback occurs.


## v0.5.6 Tumblr Rate Limit Handling

This version adds Tumblr rate-limit awareness.

Changes:
- Captures Tumblr rate-limit headers when present:
  - `X-RateLimit-Limit`
  - `X-RateLimit-Remaining`
  - `X-RateLimit-Reset`
  - `Retry-After`
- Stores the latest Tumblr rate-limit status in WordPress.
- Displays the latest rate-limit status on the Queue / Logs page.
- Handles HTTP 429 by rescheduling the queue item instead of failing it immediately.
- Uses `Retry-After` or reset timing when available.
- Adds rate-limited count to the Process Queue Now result notice.
- Stores rate-limit details in the queue response for troubleshooting.

## v0.5.6 GitHub Auto-Updater

This version adds a lightweight GitHub manifest-based updater.

- Adds `Update URI` to the plugin header.
- Checks the RavenHawkTech GitHub repository for an update manifest.
- Allows WordPress Admin to show plugin updates for this custom plugin.
- Uses the manifest file:

```text
updates/ravenhawk-tumblr-publisher.json
```

- Downloads the release ZIP from the repository when an update is available.


## v0.5.6 Checksum Verification

This version adds update package checksum verification.

- Reads `sha256` from the GitHub update manifest.
- Hashes the downloaded update ZIP before install.
- Blocks installation if the downloaded ZIP does not match the manifest checksum.


## v0.5.6 Rate-Limit Display Clarification

Tumblr does not always return rate-limit headers on normal API responses.

This version:
- Stops showing misleading `unknown` values as if the plugin failed.
- Shows whether Tumblr actually provided rate-limit headers.
- Adds a local request counter for requests made by this WordPress plugin.
- Shows local requests today, local requests this hour, last HTTP status, and last request time.
- Keeps existing HTTP 429 handling and rescheduling behavior.


## v0.5.6 Hotfix

Fixes a queue processing fatal error introduced in v0.5.5:

```text
Call to undefined method RSP_Tumblr_OAuth::record_local_usage()
```

The local Tumblr request counter helper is now included inside the OAuth helper class correctly.


## v2.0.0 RavenHawkTech Menu Update

- Renamed/repackaged the plugin as RavenHawk Tumblr Publisher.
- Moved admin navigation under **RavenHawkTech → Tumblr Publisher**.
- Added shared RavenHawkTech admin menu icon assets.
- Updated package/update metadata for the standalone GitHub repository.
- Preserved existing Tumblr OAuth, queue, logging, and publishing behavior.


## 2.0.1

- Queue/log view now displays a compact Tumblr result summary instead of the full raw JSON.
- Raw Tumblr response is still preserved and available under a collapsible "View raw response" details block.
- Successful Tumblr API responses now include an internal `_ravenhawk_compact_summary` field for easier troubleshooting.


## 2.0.2

- Added RavenHawkTech-style admin header blocks to the Tumblr Publisher admin pages.
- Removed the old workflow text reference.
