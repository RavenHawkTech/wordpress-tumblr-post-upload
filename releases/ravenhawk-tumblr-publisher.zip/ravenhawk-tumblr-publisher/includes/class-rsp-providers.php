<?php
if (!defined('ABSPATH')) {
    exit;
}

abstract class RSP_Provider {
    abstract public function publish(int $post_id, string $message): array;

    protected function featured_image_url(int $post_id): string {
        $url = get_the_post_thumbnail_url($post_id, 'full');
        return $url ?: '';
    }

    protected function tumblr_safe_featured_image_file(int $post_id): string {
        $attachment_id = get_post_thumbnail_id($post_id);
        if (!$attachment_id) {
            return '';
        }

        $file = get_attached_file($attachment_id);
        if (!$file || !file_exists($file)) {
            return '';
        }

        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'], true)) {
            return $file;
        }

        return $this->convert_attachment_to_tumblr_jpeg_file($attachment_id);
    }

    protected function convert_attachment_to_tumblr_jpeg_file(int $attachment_id): string {
        $existing = get_post_meta($attachment_id, '_rsp_tumblr_jpeg_file', true);
        if (is_string($existing) && $existing !== '' && file_exists($existing)) {
            return $existing;
        }

        $file = get_attached_file($attachment_id);
        if (!$file || !file_exists($file)) {
            return '';
        }

        if (!function_exists('wp_get_image_editor')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $editor = wp_get_image_editor($file);
        if (is_wp_error($editor)) {
            return '';
        }

        $uploads = wp_upload_dir();
        if (!empty($uploads['error'])) {
            return '';
        }

        $dir = trailingslashit($uploads['basedir']) . 'ravenhawk-tumblr';
        if (!wp_mkdir_p($dir)) {
            return '';
        }

        $target = trailingslashit($dir) . 'tumblr-' . $attachment_id . '-' . md5((string) filemtime($file)) . '.jpg';

        $saved = $editor->save($target, 'image/jpeg');
        if (is_wp_error($saved) || empty($saved['path']) || !file_exists($saved['path'])) {
            return '';
        }

        update_post_meta($attachment_id, '_rsp_tumblr_jpeg_file', $saved['path']);

        return $saved['path'];
    }


    protected function tumblr_safe_featured_image_url(int $post_id): string {
        $attachment_id = get_post_thumbnail_id($post_id);
        if (!$attachment_id) {
            return '';
        }

        $url = wp_get_attachment_image_url($attachment_id, 'full');
        if (!$url) {
            return '';
        }

        if ($this->is_tumblr_supported_image_url($url)) {
            return $url;
        }

        $converted = $this->convert_attachment_to_tumblr_jpeg($attachment_id);
        if ($converted) {
            return $converted;
        }

        foreach (['large', 'medium_large', 'medium', 'thumbnail'] as $size) {
            $candidate = wp_get_attachment_image_url($attachment_id, $size);
            if ($candidate && $this->is_tumblr_supported_image_url($candidate)) {
                return $candidate;
            }
        }

        return '';
    }

    protected function is_tumblr_supported_image_url(string $url): bool {
        $path = (string) wp_parse_url($url, PHP_URL_PATH);
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));

        return in_array($ext, ['jpg', 'jpeg', 'png', 'gif'], true);
    }

    protected function convert_attachment_to_tumblr_jpeg(int $attachment_id): string {
        $existing = get_post_meta($attachment_id, '_rsp_tumblr_jpeg_url', true);
        if (is_string($existing) && $existing !== '') {
            return esc_url_raw($existing);
        }

        $file = get_attached_file($attachment_id);
        if (!$file || !file_exists($file)) {
            return '';
        }

        if (!function_exists('wp_get_image_editor')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $editor = wp_get_image_editor($file);
        if (is_wp_error($editor)) {
            return '';
        }

        $uploads = wp_upload_dir();
        if (!empty($uploads['error'])) {
            return '';
        }

        $dir = trailingslashit($uploads['basedir']) . 'ravenhawk-tumblr';
        $url_base = trailingslashit($uploads['baseurl']) . 'ravenhawk-tumblr';

        if (!wp_mkdir_p($dir)) {
            return '';
        }

        $target = trailingslashit($dir) . 'tumblr-' . $attachment_id . '-' . md5((string) filemtime($file)) . '.jpg';

        $saved = $editor->save($target, 'image/jpeg');
        if (is_wp_error($saved) || empty($saved['path']) || !file_exists($saved['path'])) {
            return '';
        }

        $url = trailingslashit($url_base) . basename($saved['path']);
        update_post_meta($attachment_id, '_rsp_tumblr_jpeg_url', esc_url_raw($url));

        return esc_url_raw($url);
    }
}

class RSP_Tumblr_Provider extends RSP_Provider {
    public function publish(int $post_id, string $message): array {
        $blog = trim((string) get_option('rsp_tumblr_blog_identifier'));
        $consumer_key = trim((string) get_option('rsp_tumblr_consumer_key'));
        $consumer_secret = trim((string) get_option('rsp_tumblr_consumer_secret'));
        $token = trim((string) get_option('rsp_tumblr_oauth_token'));
        $token_secret = trim((string) get_option('rsp_tumblr_oauth_token_secret'));
        $state = trim((string) get_option('rsp_tumblr_state', 'queue'));
        $tags = trim((string) get_option('rsp_tumblr_tags', 'RavenHawkTech, Technology, IT, Cybersecurity, Homelab'));

        if (!$blog || !$consumer_key || !$consumer_secret || !$token || !$token_secret) {
            throw new RuntimeException('Tumblr blog identifier or OAuth connection is missing. Go to RavenHawk Social and use Connect Tumblr.');
        }

        if (!in_array($state, ['published', 'queue', 'draft', 'private'], true)) {
            $state = 'queue';
        }

        $post = get_post($post_id);
        if (!$post) {
            throw new RuntimeException('WordPress post was not found.');
        }

        $permalink = get_permalink($post_id);
        $title = get_the_title($post_id);
        $excerpt = has_excerpt($post_id) ? get_the_excerpt($post_id) : wp_trim_words(wp_strip_all_tags($post->post_content), 36);
        $endpoint = 'https://api.tumblr.com/v2/blog/' . rawurlencode($blog) . '/post';

        $image_file = $this->tumblr_safe_featured_image_file($post_id);

        if ($image_file && file_exists($image_file)) {
            $image_data = file_get_contents($image_file);

            if ($image_data !== false && strlen($image_data) > 0) {
                $params = [
                    'type' => 'photo',
                    'state' => $state,
                    'data64' => base64_encode($image_data),
                    'caption' => $this->build_html_caption($title, $excerpt, $permalink, $message),
                    'link' => $permalink,
                    'tags' => $tags,
                ];
            } else {
                $params = [
                    'type' => 'link',
                    'state' => $state,
                    'title' => $title,
                    'url' => $permalink,
                    'description' => $this->build_html_caption($title, $excerpt, $permalink, $message),
                    'tags' => $tags,
                ];
            }
        } else {
            $params = [
                'type' => 'link',
                'state' => $state,
                'title' => $title,
                'url' => $permalink,
                'description' => $this->build_html_caption($title, $excerpt, $permalink, $message),
                'tags' => $tags,
            ];
        }

        try {
            return RSP_Tumblr_OAuth::post($endpoint, $params, $consumer_key, $consumer_secret, $token, $token_secret);
        } catch (RuntimeException $e) {
            // If Tumblr rejects a photo upload, retry as a link post so the queue does not stay failed.
            if (($params['type'] ?? '') === 'photo') {
                $fallback = [
                    'type' => 'link',
                    'state' => $state,
                    'title' => $title,
                    'url' => $permalink,
                    'description' => $this->build_html_caption($title, $excerpt, $permalink, $message)
                        . '<p><em>Note: Featured image upload was skipped after Tumblr rejected the image payload.</em></p>',
                    'tags' => $tags,
                ];

                $result = RSP_Tumblr_OAuth::post($endpoint, $fallback, $consumer_key, $consumer_secret, $token, $token_secret);
                $result['ravenhawk_fallback'] = 'photo_upload_failed_link_post_created';
                $result['ravenhawk_original_error'] = $e->getMessage();

                return $result;
            }

            throw $e;
        }
    }

    private function build_html_caption(string $title, string $excerpt, string $permalink, string $message): string {
        $safe_title = esc_html($title);
        $safe_excerpt = esc_html($excerpt);
        $safe_url = esc_url($permalink);
        $safe_message = nl2br(esc_html($message));

        return '<p><strong>' . $safe_title . '</strong></p>'
            . '<p>' . $safe_excerpt . '</p>'
            . '<p><a href="' . $safe_url . '">Read the full article on RavenHawkTech</a></p>'
            . '<hr><p>' . $safe_message . '</p>';
    }
}


class RSP_Tumblr_API_Exception extends RuntimeException {
    protected array $rate_limit;
    protected int $http_status;
    protected string $response_body;

    public function __construct(string $message, array $rate_limit = [], int $http_status = 0, string $response_body = '') {
        parent::__construct($message);
        $this->rate_limit = $rate_limit;
        $this->http_status = $http_status;
        $this->response_body = $response_body;
    }

    public function get_rate_limit(): array {
        return $this->rate_limit;
    }

    public function get_http_status(): int {
        return $this->http_status;
    }

    public function get_response_body(): string {
        return $this->response_body;
    }
}

class RSP_Tumblr_RateLimit_Exception extends RSP_Tumblr_API_Exception {}

class RSP_Tumblr_OAuth {
    public static function post(string $url, array $params, string $consumer_key, string $consumer_secret, string $token = '', string $token_secret = ''): array {
        $oauth = [
            'oauth_consumer_key' => $consumer_key,
            'oauth_nonce' => wp_generate_password(24, false, false),
            'oauth_signature_method' => 'HMAC-SHA1',
            'oauth_timestamp' => (string) time(),
            'oauth_version' => '1.0',
        ];

        if ($token !== '') {
            $oauth['oauth_token'] = $token;
        }

        $signature_params = array_merge($oauth, $params);
        ksort($signature_params);

        $base_parts = [];
        foreach ($signature_params as $key => $value) {
            $base_parts[] = rawurlencode((string) $key) . '=' . rawurlencode((string) $value);
        }

        $base_string = 'POST&' . rawurlencode($url) . '&' . rawurlencode(implode('&', $base_parts));
        $signing_key = rawurlencode($consumer_secret) . '&' . rawurlencode($token_secret);
        $oauth['oauth_signature'] = base64_encode(hash_hmac('sha1', $base_string, $signing_key, true));

        $auth_parts = [];
        foreach ($oauth as $key => $value) {
            $auth_parts[] = rawurlencode($key) . '="' . rawurlencode((string) $value) . '"';
        }

        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'OAuth ' . implode(', ', $auth_parts),
                'Content-Type' => 'application/x-www-form-urlencoded',
            ],
            'body' => $params,
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            throw new RuntimeException($response->get_error_message());
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $headers = wp_remote_retrieve_headers($response);
        $rate = self::extract_rate_limit($headers);

        $local_usage = self::record_local_usage($code);
        $rate['local_usage'] = $local_usage;

        update_option('rsp_tumblr_last_rate_limit', $rate, false);

        $json = json_decode($body, true);
        $result = is_array($json) ? $json : ['raw' => $body];
        $result['ravenhawk_rate_limit'] = $rate;
        $result['ravenhawk_http_status'] = $code;

        if ($code === 429) {
            throw new RSP_Tumblr_RateLimit_Exception('Tumblr rate limit reached.', $rate, $code, $body);
        }

        if ($code < 200 || $code >= 300) {
            throw new RSP_Tumblr_API_Exception('Tumblr HTTP ' . $code . ': ' . $body, $rate, $code, $body);
        }

        return $result;
    }

    private static function record_local_usage(int $http_status): array {
        $now = current_time('timestamp', true);
        $today = gmdate('Y-m-d', $now);
        $hour = gmdate('Y-m-d-H', $now);

        $usage = get_option('rsp_tumblr_local_usage', []);
        if (!is_array($usage)) {
            $usage = [];
        }

        if (($usage['day'] ?? '') !== $today) {
            $usage['day'] = $today;
            $usage['day_count'] = 0;
        }

        if (($usage['hour'] ?? '') !== $hour) {
            $usage['hour'] = $hour;
            $usage['hour_count'] = 0;
        }

        $usage['day_count'] = (int) ($usage['day_count'] ?? 0) + 1;
        $usage['hour_count'] = (int) ($usage['hour_count'] ?? 0) + 1;
        $usage['last_http_status'] = $http_status;
        $usage['last_request_at'] = current_time('mysql');
        $usage['note'] = 'Local counter only. Tumblr did not provide authoritative rate-limit headers on this response.';

        update_option('rsp_tumblr_local_usage', $usage, false);

        return $usage;
    }

    private static function extract_rate_limit($headers): array {
        $get_header = static function ($name) use ($headers) {
            if (is_object($headers) && method_exists($headers, 'offsetGet')) {
                $value = $headers->offsetGet($name);
                if ($value !== null) {
                    return is_array($value) ? reset($value) : $value;
                }
            }

            if (is_array($headers)) {
                foreach ($headers as $key => $value) {
                    if (strtolower((string) $key) === strtolower($name)) {
                        return is_array($value) ? reset($value) : $value;
                    }
                }
            }

            return null;
        };

        $limit = $get_header('x-ratelimit-limit');
        $remaining = $get_header('x-ratelimit-remaining');
        $reset = $get_header('x-ratelimit-reset');
        $retry_after = $get_header('retry-after');

        $header_present = ($limit !== null || $remaining !== null || $reset !== null || $retry_after !== null);

        return [
            'limit' => is_numeric($limit) ? (int) $limit : $limit,
            'remaining' => is_numeric($remaining) ? (int) $remaining : $remaining,
            'reset' => is_numeric($reset) ? (int) $reset : $reset,
            'retry_after' => is_numeric($retry_after) ? (int) $retry_after : $retry_after,
            'headers_present' => $header_present,
            'note' => $header_present ? 'Tumblr rate-limit headers were provided.' : 'Tumblr did not provide rate-limit headers on this response.',
            'checked_at' => current_time('mysql'),
        ];
    }
}


class RSP_Providers {
    public static function make(string $platform): RSP_Provider {
        return match ($platform) {
            'tumblr' => new RSP_Tumblr_Provider(),
            default => throw new InvalidArgumentException('Unknown platform: ' . $platform),
        };
    }
}
