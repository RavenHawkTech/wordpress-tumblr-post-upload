<?php
if (!defined('ABSPATH')) {
    exit;
}

class RSP_Queue {
    public const CRON_HOOK = 'rsp_process_queue';

    public static function init(): void {
        add_action(self::CRON_HOOK, [__CLASS__, 'process_queue']);
    }

    public static function activate(): void {
        self::create_tables();
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 60, 'five_minutes', self::CRON_HOOK);
        }
    }

    public static function deactivate(): void {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    public static function create_tables(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();
        $table = self::table_name();

        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            platform VARCHAR(32) NOT NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'queued',
            attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
            scheduled_at DATETIME NOT NULL,
            published_at DATETIME NULL,
            remote_id VARCHAR(255) NULL,
            message TEXT NULL,
            response LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY status_scheduled (status, scheduled_at),
            KEY post_platform (post_id, platform)
        ) {$charset};";

        dbDelta($sql);
    }

    public static function table_name(): string {
        global $wpdb;
        return $wpdb->prefix . 'rsp_queue';
    }

    public static function enqueue_post(int $post_id, ?array $platforms = null): void {
        global $wpdb;

        $platforms = $platforms ?: self::selected_platforms($post_id);
        if (empty($platforms)) {
            return;
        }

        $caption = self::build_caption($post_id);
        $now = current_time('mysql');

        foreach ($platforms as $platform) {
            $wpdb->insert(self::table_name(), [
                'post_id' => $post_id,
                'platform' => sanitize_key($platform),
                'status' => 'queued',
                'attempts' => 0,
                'scheduled_at' => $now,
                'message' => $caption,
                'created_at' => $now,
                'updated_at' => $now,
            ], ['%d','%s','%s','%d','%s','%s','%s','%s']);
        }
    }

    public static function selected_platforms(int $post_id): array {
        $platforms = [];

        if (get_post_meta($post_id, '_rsp_tumblr', true) === '1') {
            $platforms[] = 'tumblr';
        }

        return $platforms;
    }

    public static function build_caption(int $post_id): string {
        $custom = trim((string) get_post_meta($post_id, '_rsp_caption', true));
        if ($custom !== '') {
            return $custom;
        }

        $post = get_post($post_id);
        $excerpt = has_excerpt($post_id) ? get_the_excerpt($post_id) : wp_trim_words(wp_strip_all_tags($post->post_content), 28);
        $hashtags = trim((string) get_option('rsp_default_hashtags', '#RavenHawkTech #Technology #IT'));

        return trim(get_the_title($post_id) . "\n\n" . $excerpt . "\n\nRead more: " . get_permalink($post_id) . "\n\n" . $hashtags);
    }


    public static function clear_queue(string $scope = 'all'): int {
        global $wpdb;

        $table = self::table_name();

        if ($scope === 'failed') {
            return (int) $wpdb->query("DELETE FROM {$table} WHERE status = 'failed'");
        }

        if ($scope === 'published') {
            return (int) $wpdb->query("DELETE FROM {$table} WHERE status = 'published'");
        }

        if ($scope === 'queued') {
            return (int) $wpdb->query("DELETE FROM {$table} WHERE status = 'queued'");
        }

        return (int) $wpdb->query("TRUNCATE TABLE {$table}");
    }

    public static function process_queue(bool $force = false): array {
        global $wpdb;

        if ($force) {
            $rows = $wpdb->get_results(
                "SELECT * FROM " . self::table_name() . " WHERE status IN ('queued','failed') ORDER BY id ASC LIMIT 10"
            );
        } else {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM " . self::table_name() . " WHERE status = %s AND scheduled_at <= %s ORDER BY id ASC LIMIT 5",
                'queued',
                current_time('mysql')
            ));
        }

        $result = [
            'found' => count($rows),
            'published' => 0,
            'failed' => 0,
            'skipped' => 0,
            'rate_limited' => 0,
        ];

        foreach ($rows as $row) {
            if ($force && $row->status === 'failed') {
                $wpdb->update(self::table_name(), [
                    'status' => 'queued',
                    'attempts' => 0,
                    'scheduled_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql'),
                ], ['id' => $row->id], ['%s','%d','%s','%s'], ['%d']);
                $row->status = 'queued';
                $row->attempts = 0;
                $row->scheduled_at = current_time('mysql');
            }

            $item_result = self::process_item($row);
            if ($item_result === 'published') {
                $result['published']++;
            } elseif ($item_result === 'failed') {
                $result['failed']++;
            } elseif ($item_result === 'rate_limited') {
                $result['rate_limited']++;
            } else {
                $result['skipped']++;
            }
        }

        return $result;
    }

    public static function process_item(object $row): string {
        global $wpdb;

        $provider = RSP_Providers::make($row->platform);
        $now = current_time('mysql');

        try {
            $result = $provider->publish((int) $row->post_id, (string) $row->message);
            $remote_id = $result['response']['id'] ?? $result['id'] ?? null;

            $wpdb->update(self::table_name(), [
                'status' => 'published',
                'published_at' => $now,
                'remote_id' => is_scalar($remote_id) ? (string) $remote_id : null,
                'response' => wp_json_encode($result),
                'updated_at' => $now,
            ], ['id' => $row->id], ['%s','%s','%s','%s','%s'], ['%d']);

            return 'published';
        } catch (RSP_Tumblr_RateLimit_Exception $e) {
            $attempts = (int) $row->attempts + 1;
            $rate = $e->get_rate_limit();
            $delay = 15 * MINUTE_IN_SECONDS;

            if (!empty($rate['retry_after']) && is_numeric($rate['retry_after'])) {
                $delay = max(60, (int) $rate['retry_after']);
            } elseif (!empty($rate['reset']) && is_numeric($rate['reset'])) {
                $delay = max(60, ((int) $rate['reset']) - current_time('timestamp', true));
            }

            $next = gmdate('Y-m-d H:i:s', current_time('timestamp', true) + $delay);

            $wpdb->update(self::table_name(), [
                'status' => 'queued',
                'attempts' => $attempts,
                'scheduled_at' => get_date_from_gmt($next),
                'response' => wp_json_encode([
                    'message' => $e->getMessage(),
                    'rate_limit' => $rate,
                    'http_status' => $e->get_http_status(),
                    'rescheduled_for' => get_date_from_gmt($next),
                ]),
                'updated_at' => $now,
            ], ['id' => $row->id], ['%s','%d','%s','%s','%s'], ['%d']);

            return 'rate_limited';
        } catch (RSP_Tumblr_API_Exception $e) {
            $attempts = (int) $row->attempts + 1;
            $status = $attempts >= 3 ? 'failed' : 'queued';
            $next = gmdate('Y-m-d H:i:s', current_time('timestamp', true) + ($attempts * 10 * MINUTE_IN_SECONDS));

            $wpdb->update(self::table_name(), [
                'status' => $status,
                'attempts' => $attempts,
                'scheduled_at' => get_date_from_gmt($next),
                'response' => wp_json_encode([
                    'message' => $e->getMessage(),
                    'rate_limit' => $e->get_rate_limit(),
                    'http_status' => $e->get_http_status(),
                ]),
                'updated_at' => $now,
            ], ['id' => $row->id], ['%s','%d','%s','%s','%s'], ['%d']);

            return 'failed';
        } catch (Throwable $e) {
            $attempts = (int) $row->attempts + 1;
            $status = $attempts >= 3 ? 'failed' : 'queued';
            $next = gmdate('Y-m-d H:i:s', current_time('timestamp', true) + ($attempts * 10 * MINUTE_IN_SECONDS));

            $wpdb->update(self::table_name(), [
                'status' => $status,
                'attempts' => $attempts,
                'scheduled_at' => get_date_from_gmt($next),
                'response' => $e->getMessage(),
                'updated_at' => $now,
            ], ['id' => $row->id], ['%s','%d','%s','%s','%s'], ['%d']);

            return 'failed';
        }
    }
}

add_filter('cron_schedules', function ($schedules) {
    $schedules['five_minutes'] = [
        'interval' => 300,
        'display' => __('Every five minutes', 'ravenhawk-social-publisher'),
    ];

    return $schedules;
});
