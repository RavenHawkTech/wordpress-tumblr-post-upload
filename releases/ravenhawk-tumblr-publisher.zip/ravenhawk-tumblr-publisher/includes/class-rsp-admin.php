<?php
if (!defined('ABSPATH')) {
    exit;
}

class RSP_Admin {
    public static function init(): void {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_init', [__CLASS__, 'settings']);
        add_action('admin_init', [__CLASS__, 'maybe_handle_tumblr_admin_callback']);
        add_action('add_meta_boxes', [__CLASS__, 'metabox']);
        add_action('save_post_post', [__CLASS__, 'save_post'], 10, 2);
        add_action('admin_post_rsp_queue_now', [__CLASS__, 'queue_now']);
        add_action('admin_post_rsp_process_queue_now', [__CLASS__, 'process_queue_now']);
        add_action('admin_post_rsp_clear_queue', [__CLASS__, 'clear_queue']);
        add_action('admin_post_rsp_tumblr_connect', [__CLASS__, 'tumblr_connect']);
        add_action('admin_post_rsp_tumblr_oauth_callback', [__CLASS__, 'tumblr_oauth_callback']);
        add_action('admin_post_rsp_tumblr_disconnect', [__CLASS__, 'tumblr_disconnect']);
    }

    public static function menu(): void {
        if (!self::admin_menu_slug_exists('ravenhawktech')) {
            add_menu_page(
                'RavenHawkTech',
                'RavenHawkTech',
                'manage_options',
                'ravenhawktech',
                [__CLASS__, 'render_ravenhawktech_page'],
                self::admin_menu_icon_url(),
                81
            );
        }

        add_submenu_page(
            'ravenhawktech',
            'RavenHawk Tumblr Publisher',
            'Tumblr Publisher',
            'manage_options',
            'rsp-settings',
            [__CLASS__, 'settings_page']
        );

        add_submenu_page(
            'ravenhawktech',
            'Tumblr Queue',
            'Tumblr Queue / Logs',
            'manage_options',
            'rsp-queue',
            [__CLASS__, 'queue_page']
        );
    }

    private static function admin_menu_slug_exists(string $slug): bool {
        global $menu;

        if (!is_array($menu)) {
            return false;
        }

        foreach ($menu as $item) {
            if (isset($item[2]) && $item[2] === $slug) {
                return true;
            }
        }

        return false;
    }

    private static function admin_menu_icon_url(): string {
        return plugin_dir_url(RSP_PLUGIN_FILE) . 'assets/rht-admin-menu-icon.png';
    }

    private static function branding_icon_url(): string {
        return plugin_dir_url(RSP_PLUGIN_FILE) . 'assets/rht-admin-heading-icon.png';
    }


    private static function render_admin_header(string $title, string $subtitle = ''): void {
        ?>
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:18px;padding:14px 18px;background:#111827;border-left:4px solid #dc2626;border-radius:10px;color:#f9fafb;">
            <div style="font-size:28px;">📝</div>
            <div>
                <h1 style="margin:0;color:#fff;"><?php echo esc_html($title); ?></h1>
                <?php if ($subtitle !== ''): ?>
                    <p style="margin:4px 0 0;color:#d1d5db;"><?php echo esc_html($subtitle); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    public static function render_ravenhawktech_page(): void {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1>
                <img src="<?php echo esc_url(self::branding_icon_url()); ?>" alt="" style="width: 20px; height: 20px; vertical-align: text-bottom; margin-right: 6px;">
                <a href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">RavenHawkTech</a>
            </h1>
            <p>RavenHawkTech WordPress tools and connectors.</p>
            <p><a class="button button-primary" href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">Visit RavenHawkTech</a></p>
        </div>
        <?php
    }

    public static function settings(): void {
        $fields = [
            'rsp_default_hashtags',
            'rsp_tumblr_blog_identifier',
            'rsp_tumblr_consumer_key',
            'rsp_tumblr_consumer_secret',
            'rsp_tumblr_state',
            'rsp_tumblr_tags',
        ];

        foreach ($fields as $field) {
            register_setting('rsp_settings', $field, [
                'sanitize_callback' => str_contains($field, 'secret') || str_contains($field, 'key')
                    ? [__CLASS__, 'sanitize_secret']
                    : 'sanitize_text_field',
            ]);
        }
    }

    public static function sanitize_secret($value): string {
        return sanitize_text_field((string) $value);
    }

    public static function settings_page(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        $consumer_key = trim((string) get_option('rsp_tumblr_consumer_key'));
        $consumer_secret = trim((string) get_option('rsp_tumblr_consumer_secret'));
        $token = trim((string) get_option('rsp_tumblr_oauth_token'));
        $token_secret = trim((string) get_option('rsp_tumblr_oauth_token_secret'));
        $connected = $token !== '' && $token_secret !== '';
        $callback_url = admin_url('admin.php?page=rsp-settings&rsp_tumblr_oauth_callback=1');
        ?>
        <div class="wrap">
            <?php self::render_admin_header('RavenHawk Tumblr Publisher', 'Publish WordPress posts to Tumblr and manage publishing settings.'); ?>
            <p>Basic Tumblr publishing tools for WordPress posts, queue processing, OAuth connection, and post logging. Visit <a href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">RavenHawkTech</a>.</p>

            <?php if (isset($_GET['rsp_notice'])): ?>
                <div class="notice notice-success"><p><?php echo esc_html(sanitize_text_field(wp_unslash($_GET['rsp_notice']))); ?></p></div>
            <?php endif; ?>
            <?php if (isset($_GET['rsp_error'])): ?>
                <div class="notice notice-error"><p><?php echo esc_html(sanitize_text_field(wp_unslash($_GET['rsp_error']))); ?></p></div>
            <?php endif; ?>

            <p><strong>Workflow:</strong> WordPress → Tumblr → Instagram → Facebook</p>
            <p>This plugin now focuses only on Tumblr. Your existing Tumblr automation can continue forwarding posts to Instagram and Facebook.</p>

            <form method="post" action="options.php">
                <?php settings_fields('rsp_settings'); ?>

                <h2>Tumblr App Settings</h2>
                <table class="form-table">
                    <tr>
                        <th>OAuth2 / OAuth1 Redirect URL</th>
                        <td>
                            <code><?php echo esc_html($callback_url); ?></code>
                            <p class="description">Use this as the primary Tumblr callback URL. This build handles the callback directly inside the plugin settings page.</p>
                            <p class="description">Fallback callback also supported: <code><?php echo esc_html(site_url('/wp-admin/admin-post.php?action=rsp_tumblr_oauth_callback')); ?></code></p>
                        </td>
                    </tr>
                    <tr>
                        <th>Tumblr Blog Identifier</th>
                        <td>
                            <input class="regular-text" name="rsp_tumblr_blog_identifier" value="<?php echo esc_attr(get_option('rsp_tumblr_blog_identifier')); ?>" placeholder="yourblog.tumblr.com">
                            <p class="description">Use the Tumblr blog hostname, such as <code>yourblog.tumblr.com</code>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Tumblr OAuth Key</th>
                        <td>
                            <input class="large-text" type="password" name="rsp_tumblr_consumer_key" value="<?php echo esc_attr($consumer_key); ?>">
                            <p class="description">Tumblr may label this as OAuth Consumer Key, OAuth Key, or Consumer Key.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Tumblr OAuth Secret</th>
                        <td>
                            <input class="large-text" type="password" name="rsp_tumblr_consumer_secret" value="<?php echo esc_attr($consumer_secret); ?>">
                            <p class="description">Tumblr may label this as OAuth Consumer Secret, OAuth Secret, or Consumer Secret.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Default Tumblr State</th>
                        <td>
                            <select name="rsp_tumblr_state">
                                <?php $state = get_option('rsp_tumblr_state', 'queue'); ?>
                                <option value="queue" <?php selected($state, 'queue'); ?>>Queue recommended</option>
                                <option value="draft" <?php selected($state, 'draft'); ?>>Draft</option>
                                <option value="published" <?php selected($state, 'published'); ?>>Publish immediately</option>
                                <option value="private" <?php selected($state, 'private'); ?>>Private</option>
                            </select>
                            <p class="description">Use Queue while testing the Tumblr → Instagram → Facebook chain.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Tumblr Tags</th>
                        <td><input class="regular-text" name="rsp_tumblr_tags" value="<?php echo esc_attr(get_option('rsp_tumblr_tags', 'RavenHawkTech, Technology, IT, Cybersecurity, Homelab')); ?>"></td>
                    </tr>
                    <tr>
                        <th>Default Hashtags</th>
                        <td><input class="regular-text" name="rsp_default_hashtags" value="<?php echo esc_attr(get_option('rsp_default_hashtags', '#RavenHawkTech #Technology #IT')); ?>"></td>
                    </tr>
                </table>

                <?php submit_button('Save Tumblr Settings'); ?>
            </form>

            <h2>Tumblr OAuth Connection</h2>
            <table class="widefat striped" style="max-width: 900px;">
                <tbody>
                    <tr><th>Status</th><td><?php echo $connected ? '<strong style="color:green;">Connected</strong>' : '<strong style="color:#a00;">Not connected</strong>'; ?></td></tr>
                    <tr><th>OAuth Token Stored</th><td><?php echo $token ? 'Yes' : 'No'; ?></td></tr>
                    <tr><th>OAuth Token Secret Stored</th><td><?php echo $token_secret ? 'Yes' : 'No'; ?></td></tr>
                </tbody>
            </table>

            <?php if (get_option('rsp_tumblr_last_authorize_url')): ?>
                <p><strong>Last Tumblr authorize URL:</strong><br>
                <code style="word-break:break-all;"><?php echo esc_html(get_option('rsp_tumblr_last_authorize_url')); ?></code></p>
            <?php endif; ?>

            <p>
                <?php if ($consumer_key && $consumer_secret): ?>
                    <a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rsp_tumblr_connect'), 'rsp_tumblr_connect')); ?>">Connect Tumblr</a>
                <?php else: ?>
                    <button class="button button-primary" disabled>Connect Tumblr</button>
                    <span class="description">Save Tumblr OAuth Key and OAuth Secret first.</span>
                <?php endif; ?>

                <?php if ($connected): ?>
                    <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rsp_tumblr_disconnect'), 'rsp_tumblr_disconnect')); ?>">Disconnect Tumblr</a>
                <?php endif; ?>
            </p>
        </div>
        <?php
    }

    public static function tumblr_connect(): void {
        if (!current_user_can('manage_options') || !check_admin_referer('rsp_tumblr_connect')) {
            wp_die('Unauthorized');
        }

        $consumer_key = trim((string) get_option('rsp_tumblr_consumer_key'));
        $consumer_secret = trim((string) get_option('rsp_tumblr_consumer_secret'));

        if (!$consumer_key || !$consumer_secret) {
            self::redirect_error('Save Tumblr OAuth Key and OAuth Secret first.');
        }

        try {
            $callback = admin_url('admin.php?page=rsp-settings&rsp_tumblr_oauth_callback=1');
            $result = self::oauth1_post(
                'https://www.tumblr.com/oauth/request_token',
                [],
                $consumer_key,
                $consumer_secret,
                '',
                '',
                ['oauth_callback' => $callback]
            );

            if (empty($result['oauth_token']) || empty($result['oauth_token_secret'])) {
                throw new RuntimeException('Tumblr did not return a temporary OAuth token.');
            }

            set_transient('rsp_tumblr_request_secret_' . get_current_user_id(), $result['oauth_token_secret'], 15 * MINUTE_IN_SECONDS);
            set_transient('rsp_tumblr_request_secret_token_' . sanitize_key($result['oauth_token']), $result['oauth_token_secret'], 15 * MINUTE_IN_SECONDS);

            $authorize_url = add_query_arg([
                'oauth_token' => $result['oauth_token'],
            ], 'https://www.tumblr.com/oauth/authorize');

            update_option('rsp_tumblr_last_authorize_url', esc_url_raw($authorize_url), false);

            wp_redirect($authorize_url);
            exit;
        } catch (Throwable $e) {
            self::redirect_error($e->getMessage());
        }
    }


    public static function maybe_handle_tumblr_admin_callback(): void {
        if (!is_admin()) {
            return;
        }

        if (($_GET['page'] ?? '') !== 'rsp-settings') {
            return;
        }

        if (empty($_GET['rsp_tumblr_oauth_callback'])) {
            return;
        }

        self::tumblr_oauth_callback();
    }

    public static function tumblr_oauth_callback(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        $oauth_token = isset($_GET['oauth_token']) ? sanitize_text_field(wp_unslash($_GET['oauth_token'])) : '';
        $oauth_verifier = isset($_GET['oauth_verifier']) ? sanitize_text_field(wp_unslash($_GET['oauth_verifier'])) : '';
        $request_secret = get_transient('rsp_tumblr_request_secret_token_' . sanitize_key($oauth_token));
        if (!$request_secret) {
            $request_secret = get_transient('rsp_tumblr_request_secret_' . get_current_user_id());
        }

        if (!$oauth_token || !$oauth_verifier || !$request_secret) {
            self::redirect_error('Tumblr OAuth callback was missing the token, verifier, or temporary token secret. Query received: ' . wp_json_encode(array_map('sanitize_text_field', wp_unslash($_GET))) . '. Start Connect Tumblr again from this same browser session.');
        }

        $consumer_key = trim((string) get_option('rsp_tumblr_consumer_key'));
        $consumer_secret = trim((string) get_option('rsp_tumblr_consumer_secret'));

        try {
            $result = self::oauth1_post(
                'https://www.tumblr.com/oauth/access_token',
                [],
                $consumer_key,
                $consumer_secret,
                $oauth_token,
                (string) $request_secret,
                ['oauth_verifier' => $oauth_verifier]
            );

            if (empty($result['oauth_token']) || empty($result['oauth_token_secret'])) {
                throw new RuntimeException('Tumblr did not return a final OAuth token.');
            }

            update_option('rsp_tumblr_oauth_token', $result['oauth_token'], false);
            update_option('rsp_tumblr_oauth_token_secret', $result['oauth_token_secret'], false);
            delete_transient('rsp_tumblr_request_secret_' . get_current_user_id());
            delete_transient('rsp_tumblr_request_secret_token_' . sanitize_key($oauth_token));

            self::redirect_notice('Tumblr connected successfully.');
        } catch (Throwable $e) {
            self::redirect_error($e->getMessage());
        }
    }

    public static function tumblr_disconnect(): void {
        if (!current_user_can('manage_options') || !check_admin_referer('rsp_tumblr_disconnect')) {
            wp_die('Unauthorized');
        }

        delete_option('rsp_tumblr_oauth_token');
        delete_option('rsp_tumblr_oauth_token_secret');

        self::redirect_notice('Tumblr disconnected.');
    }

    private static function oauth1_post(string $url, array $params, string $consumer_key, string $consumer_secret, string $token = '', string $token_secret = '', array $oauth_extra = []): array {
        $oauth = array_merge([
            'oauth_consumer_key' => $consumer_key,
            'oauth_nonce' => wp_generate_password(24, false, false),
            'oauth_signature_method' => 'HMAC-SHA1',
            'oauth_timestamp' => (string) time(),
            'oauth_version' => '1.0',
        ], $oauth_extra);

        if ($token !== '') {
            $oauth['oauth_token'] = $token;
        }

        $signature_params = array_merge($oauth, $params);
        ksort($signature_params);

        $base_parts = [];
        foreach ($signature_params as $key => $value) {
            $base_parts[] = rawurlencode((string) $key) . '=' . rawurlencode((string) $value);
        }

        $base_string = 'POST&' . rawurlencode($url) . '&' . rawurlencode(implode('&', $base_parts));
        $signing_key = rawurlencode($consumer_secret) . '&' . rawurlencode($token_secret);
        $oauth['oauth_signature'] = base64_encode(hash_hmac('sha1', $base_string, $signing_key, true));

        $auth_parts = [];
        foreach ($oauth as $key => $value) {
            $auth_parts[] = rawurlencode($key) . '="' . rawurlencode((string) $value) . '"';
        }

        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'OAuth ' . implode(', ', $auth_parts),
                'Content-Type' => 'application/x-www-form-urlencoded',
            ],
            'body' => $params,
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            throw new RuntimeException($response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code < 200 || $code >= 300) {
            throw new RuntimeException('Tumblr OAuth HTTP ' . $code . ': ' . $body);
        }

        parse_str($body, $parsed);

        return is_array($parsed) ? $parsed : [];
    }

    private static function redirect_notice(string $message): void {
        wp_safe_redirect(add_query_arg('rsp_notice', rawurlencode($message), admin_url('admin.php?page=rsp-settings')));
        exit;
    }

    private static function redirect_error(string $message): void {
        wp_safe_redirect(add_query_arg('rsp_error', rawurlencode($message), admin_url('admin.php?page=rsp-settings')));
        exit;
    }

    public static function metabox(): void {
        add_meta_box('rsp_social', 'RavenHawk Tumblr Publisher', [__CLASS__, 'metabox_html'], 'post', 'side', 'high');
    }

    public static function metabox_html(WP_Post $post): void {
        wp_nonce_field('rsp_save_post', 'rsp_nonce');
        $enabled = get_post_meta($post->ID, '_rsp_enabled', true) === '1';
        ?>
        <p><label><input type="checkbox" name="rsp_enabled" value="1" <?php checked($enabled); ?>> Send this post to Tumblr</label></p>
        <p><label><input type="checkbox" name="rsp_tumblr" value="1" <?php checked(get_post_meta($post->ID, '_rsp_tumblr', true), '1'); ?>> Tumblr Bridge</label></p>
        <p><label>Custom Tumblr caption<br><textarea style="width:100%;min-height:110px" name="rsp_caption"><?php echo esc_textarea(get_post_meta($post->ID, '_rsp_caption', true)); ?></textarea></label></p>
        <?php if ($post->post_status === 'publish'): ?>
            <p><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rsp_queue_now&post_id=' . $post->ID), 'rsp_queue_now')); ?>">Queue Now</a></p>
        <?php endif; ?>
        <?php
    }

    public static function save_post(int $post_id, WP_Post $post): void {
        if (!isset($_POST['rsp_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['rsp_nonce'])), 'rsp_save_post')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        update_post_meta($post_id, '_rsp_enabled', isset($_POST['rsp_enabled']) ? '1' : '0');
        update_post_meta($post_id, '_rsp_tumblr', isset($_POST['rsp_tumblr']) ? '1' : '0');

        $caption = isset($_POST['rsp_caption']) ? sanitize_textarea_field(wp_unslash($_POST['rsp_caption'])) : '';
        update_post_meta($post_id, '_rsp_caption', $caption);
    }

    public static function queue_now(): void {
        if (!current_user_can('edit_posts') || !check_admin_referer('rsp_queue_now')) {
            wp_die('Unauthorized');
        }

        $post_id = absint($_GET['post_id'] ?? 0);
        if ($post_id) {
            RSP_Queue::enqueue_post($post_id, ['tumblr']);
        }

        wp_safe_redirect(wp_get_referer() ?: admin_url('admin.php?page=rsp-queue'));
        exit;
    }

    public static function process_queue_now(): void {
        if (!current_user_can('manage_options') || !check_admin_referer('rsp_process_queue_now')) {
            wp_die('Unauthorized');
        }

        $result = RSP_Queue::process_queue(true);
        $message = sprintf(
            'Process Queue Now complete. Found: %d, Published: %d, Failed: %d, Rate-limited: %d, Skipped: %d.',
            $result['found'],
            $result['published'],
            $result['failed'],
            $result['rate_limited'],
            $result['skipped']
        );

        wp_safe_redirect(add_query_arg('rsp_notice', rawurlencode($message), admin_url('admin.php?page=rsp-queue')));
        exit;
    }


    public static function clear_queue(): void {
        if (!current_user_can('manage_options') || !check_admin_referer('rsp_clear_queue')) {
            wp_die('Unauthorized');
        }

        $scope = isset($_GET['scope']) ? sanitize_key(wp_unslash($_GET['scope'])) : 'all';
        if (!in_array($scope, ['all', 'queued', 'failed', 'published'], true)) {
            $scope = 'all';
        }

        $deleted = RSP_Queue::clear_queue($scope);
        $message = sprintf('Queue cleanup complete. Scope: %s. Deleted rows: %d.', $scope, $deleted);

        wp_safe_redirect(add_query_arg('rsp_notice', rawurlencode($message), admin_url('admin.php?page=rsp-queue')));
        exit;
    }

    public static function queue_page(): void {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM " . RSP_Queue::table_name() . " ORDER BY id DESC LIMIT 100");
        ?>
        <div class="wrap">
            <?php self::render_admin_header('Tumblr Queue / Logs', 'Review queued publishing tasks, compact Tumblr responses, and raw troubleshooting details.'); ?>
            <?php if (isset($_GET['rsp_notice'])): ?>
                <div class="notice notice-success"><p><?php echo esc_html(sanitize_text_field(wp_unslash($_GET['rsp_notice']))); ?></p></div>
            <?php endif; ?>
            <?php $rate = get_option('rsp_tumblr_last_rate_limit', []); ?>
            <?php if (is_array($rate) && !empty($rate)): ?>
                <h2>Tumblr Rate Limit Status</h2>
                <table class="widefat striped" style="max-width: 900px;">
                    <tbody>
                        <tr><th>Header Status</th><td><?php echo !empty($rate['headers_present']) ? 'Provided by Tumblr' : 'Not provided by Tumblr'; ?></td></tr>
                        <tr><th>Limit</th><td><?php echo esc_html((string) ($rate['limit'] ?? 'not provided')); ?></td></tr>
                        <tr><th>Remaining</th><td><?php echo esc_html((string) ($rate['remaining'] ?? 'not provided')); ?></td></tr>
                        <tr><th>Reset</th><td><?php echo esc_html((string) ($rate['reset'] ?? 'not provided')); ?></td></tr>
                        <tr><th>Retry After</th><td><?php echo esc_html((string) ($rate['retry_after'] ?? 'not provided')); ?></td></tr>
                        <tr><th>Checked At</th><td><?php echo esc_html((string) ($rate['checked_at'] ?? 'unknown')); ?></td></tr>
                        <tr><th>Note</th><td><?php echo esc_html((string) ($rate['note'] ?? '')); ?></td></tr>
                        <?php $local = is_array($rate['local_usage'] ?? null) ? $rate['local_usage'] : get_option('rsp_tumblr_local_usage', []); ?>
                        <?php if (is_array($local) && !empty($local)): ?>
                            <tr><th>Local Requests Today</th><td><?php echo esc_html((string) ($local['day_count'] ?? 0)); ?></td></tr>
                            <tr><th>Local Requests This Hour</th><td><?php echo esc_html((string) ($local['hour_count'] ?? 0)); ?></td></tr>
                            <tr><th>Last HTTP Status</th><td><?php echo esc_html((string) ($local['last_http_status'] ?? 'unknown')); ?></td></tr>
                            <tr><th>Last Local Request</th><td><?php echo esc_html((string) ($local['last_request_at'] ?? 'unknown')); ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <p>
                <a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rsp_process_queue_now'), 'rsp_process_queue_now')); ?>">Process Queue Now / Retry Failed</a>
                <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rsp_clear_queue&scope=queued'), 'rsp_clear_queue')); ?>">Clear Queued</a>
                <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rsp_clear_queue&scope=failed'), 'rsp_clear_queue')); ?>">Clear Failed</a>
                <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rsp_clear_queue&scope=published'), 'rsp_clear_queue')); ?>">Clear Published</a>
                <a class="button button-link-delete" onclick="return confirm('Delete all queue/log rows? This cannot be undone.');" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rsp_clear_queue&scope=all'), 'rsp_clear_queue')); ?>">Clear All</a>
            </p>
            <p class="description">Process Queue Now manually sends queued items and retries failed items. Clear buttons remove queue/log rows from the local WordPress table only.</p>
            <table class="widefat striped">
                <thead><tr><th>ID</th><th>Post</th><th>Platform</th><th>Status</th><th>Attempts</th><th>Scheduled</th><th>Published</th><th>Remote ID</th><th>Result</th></tr></thead>
                <tbody>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <td><?php echo esc_html($row->id); ?></td>
                        <td><a href="<?php echo esc_url(get_edit_post_link($row->post_id)); ?>"><?php echo esc_html(get_the_title($row->post_id)); ?></a></td>
                        <td><?php echo esc_html($row->platform); ?></td>
                        <td><?php echo esc_html($row->status); ?></td>
                        <td><?php echo esc_html($row->attempts); ?></td>
                        <td><?php echo esc_html($row->scheduled_at); ?></td>
                        <td><?php echo esc_html($row->published_at); ?></td>
                        <td><?php echo esc_html($row->remote_id); ?></td>
                        <td>
                            <?php
                            $compact = RSP_Queue::compact_response_summary((string) $row->response, (string) $row->platform);
                            ?>
                            <strong><?php echo esc_html($compact ?: 'No response recorded.'); ?></strong>
                            <?php if (!empty($row->response)): ?>
                                <details style="margin-top:6px;">
                                    <summary>View raw response</summary>
                                    <code style="display:block;white-space:pre-wrap;max-height:220px;overflow:auto;margin-top:6px;"><?php echo esc_html((string) $row->response); ?></code>
                                </details>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}
