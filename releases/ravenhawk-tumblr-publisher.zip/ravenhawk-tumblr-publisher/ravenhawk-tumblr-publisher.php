<?php
/**
 * Plugin Name: RavenHawk Tumblr Publisher
 * Plugin URI: https://ravenhawktech.com
 * Description: Basic Tumblr publishing tools for WordPress posts, queue processing, OAuth connection, and post logging. Visit https://ravenhawktech.com for RavenHawkTech.
 * Version: 2.0.0
 * Author: RavenHawkTech
 * Requires at least: 6.2
 * Requires PHP: 8.0
 * Update URI: https://github.com/RavenHawkTech/wordpress-tumblr-post-upload
 */

if (!defined('ABSPATH')) {
    exit;
}

define('RSP_VERSION', '2.0.0');
define('RSP_PLUGIN_FILE', __FILE__);
define('RSP_PLUGIN_DIR', plugin_dir_path(__FILE__));

require_once RSP_PLUGIN_DIR . 'includes/class-rsp-queue.php';
require_once RSP_PLUGIN_DIR . 'includes/class-rsp-providers.php';
require_once RSP_PLUGIN_DIR . 'includes/class-rsp-admin.php';

register_activation_hook(__FILE__, ['RSP_Queue', 'activate']);
register_deactivation_hook(__FILE__, ['RSP_Queue', 'deactivate']);

add_action('plugins_loaded', function () {
    RSP_Admin::init();
    RSP_Queue::init();
});


/**
 * RavenHawk GitHub updater.
 *
 * This uses a lightweight manifest in the RHT_Wordpress repository instead of
 * WordPress.org. It lets WordPress Admin show updates for this custom plugin.
 */
class RSP_GitHub_Updater {
    private const MANIFEST_URL = 'https://raw.githubusercontent.com/RavenHawkTech/wordpress-tumblr-post-upload/main/updates/ravenhawk-tumblr-publisher.json';

    public static function init(): void {
        add_filter('pre_set_site_transient_update_plugins', [__CLASS__, 'check_for_update']);
        add_filter('plugins_api', [__CLASS__, 'plugin_info'], 20, 3);
    }

    private static function manifest(): array {
        $force_refresh = !empty($_GET['force-check']) || !empty($_GET['rsp_update_check']);
        if (!$force_refresh) {
            $cached = get_site_transient('rsp_github_update_manifest');
            if (is_array($cached)) {
                return $cached;
            }
        }

        $response = wp_remote_get(self::MANIFEST_URL, [
            'timeout' => 15,
            'headers' => [
                'Accept' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            return [];
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            return [];
        }

        $json = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($json)) {
            return [];
        }

        set_site_transient('rsp_github_update_manifest', $json, 30 * MINUTE_IN_SECONDS);

        return $json;
    }

    public static function check_for_update($transient) {
        if (empty($transient) || !is_object($transient)) {
            return $transient;
        }

        $plugin_file = plugin_basename(RSP_PLUGIN_FILE);
        $manifest = self::manifest();

        if (empty($manifest['version']) || empty($manifest['download_url'])) {
            return $transient;
        }

        if (version_compare(RSP_VERSION, (string) $manifest['version'], '<')) {
            $transient->response[$plugin_file] = (object) [
                'id' => $manifest['homepage'] ?? 'https://github.com/RavenHawkTech/wordpress-tumblr-post-upload',
                'slug' => dirname($plugin_file),
                'plugin' => $plugin_file,
                'new_version' => (string) $manifest['version'],
                'url' => $manifest['homepage'] ?? 'https://github.com/RavenHawkTech/wordpress-tumblr-post-upload',
                'package' => (string) $manifest['download_url'],
                'tested' => $manifest['tested'] ?? '',
                'requires_php' => $manifest['requires_php'] ?? '8.0',
            ];
        } else {
            unset($transient->response[$plugin_file]);
        }

        return $transient;
    }

    public static function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information') {
            return $result;
        }

        $plugin_file = plugin_basename(RSP_PLUGIN_FILE);
        if (empty($args->slug) || $args->slug !== dirname($plugin_file)) {
            return $result;
        }

        $manifest = self::manifest();
        if (!$manifest) {
            return $result;
        }

        return (object) [
            'name' => $manifest['name'] ?? 'RavenHawk Tumblr Publisher',
            'slug' => dirname($plugin_file),
            'version' => $manifest['version'] ?? RSP_VERSION,
            'author' => '<a href="https://RavenHawkTech.com">RavenHawkTech</a>',
            'homepage' => $manifest['homepage'] ?? 'https://github.com/RavenHawkTech/wordpress-tumblr-post-upload',
            'requires' => $manifest['requires'] ?? '6.2',
            'tested' => $manifest['tested'] ?? '',
            'requires_php' => $manifest['requires_php'] ?? '8.0',
            'sections' => [
                'description' => $manifest['description'] ?? 'Basic Tumblr publishing tools for WordPress posts, queue processing, OAuth connection, and post logging.',
                'changelog' => $manifest['changelog'] ?? '',
            ],
            'download_link' => $manifest['download_url'] ?? '',
        ];
    }
}

RSP_GitHub_Updater::init();

add_action('transition_post_status', function ($new_status, $old_status, $post) {
    if ($new_status !== 'publish' || $old_status === 'publish' || $post->post_type !== 'post') {
        return;
    }

    $enabled = get_post_meta($post->ID, '_rsp_enabled', true);
    if ($enabled !== '1') {
        return;
    }

    RSP_Queue::enqueue_post($post->ID);
}, 10, 3);
